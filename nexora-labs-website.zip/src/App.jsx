export default function App() {
  return (
    <div style={{background:'#000',color:'#fff',minHeight:'100vh',padding:'40px',fontFamily:'sans-serif'}}>
      <h1 style={{color:'red'}}>NEXORA LABS</h1>
      <p>Cybersecurity • Development • AI • Design</p>

      <section style={{marginTop:'40px'}}>
        <h2>Services</h2>
        <ul>
          <li>Cybersecurity</li>
          <li>Web Development</li>
          <li>Design & Graphics</li>
          <li>AI Solutions</li>
        </ul>
      </section>

      <section style={{marginTop:'40px'}}>
        <h2>Contact</h2>
        <p>WhatsApp: 01003311379</p>
        <p>Email: nexoralabs99.com</p>
      </section>

      <a href="https://wa.me/201003311379"
         style={{position:'fixed',bottom:20,right:20,background:'green',padding:'12px 18px',borderRadius:20,color:'#fff'}}>
        WhatsApp
      </a>
    </div>
  )
}
