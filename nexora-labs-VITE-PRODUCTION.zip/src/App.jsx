export default function App() {
  return (
    <div style={{
      background:'#050505',
      color:'#fff',
      minHeight:'100vh',
      fontFamily:'Arial',
      padding:'40px'
    }}>

      <header style={{borderBottom:'1px solid #222',paddingBottom:20}}>
        <h1 style={{color:'#ff0033'}}>NEXORA LABS</h1>
        <p>Cybersecurity • Development • AI • Design</p>
      </header>

      <section style={{marginTop:40}}>
        <h2>About</h2>
        <p>
          Nexora Labs is a futuristic digital company specializing in secure systems,
          modern web development, AI solutions, and creative design.
        </p>
      </section>

      <section style={{marginTop:40}}>
        <h2>Services</h2>
        <ul>
          <li>Cybersecurity & Penetration Testing</li>
          <li>Web Development (React / APIs)</li>
          <li>UI/UX & Graphic Design</li>
          <li>AI Automation Systems</li>
        </ul>
      </section>

      <section style={{marginTop:40}}>
        <h2>Contact</h2>
        <p>WhatsApp: 01003311379</p>
        <p>Email: contact@nexoralabs99.com</p>
      </section>

      <a 
        href="https://wa.me/201003311379"
        style={{
          position:'fixed',
          right:20,
          bottom:20,
          background:'green',
          padding:'14px 18px',
          borderRadius:25,
          color:'#fff',
          textDecoration:'none'
        }}
      >
        WhatsApp
      </a>

    </div>
  )
}
